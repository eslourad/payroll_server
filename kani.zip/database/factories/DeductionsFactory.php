<?php

use Faker\Generator as Faker;

$factory->define(App\deductions::class, function (Faker $faker) {
    return [
        //
    ];
});
