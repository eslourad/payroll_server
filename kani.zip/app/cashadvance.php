<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class cashadvance extends Model
{
    protected $fillable = [
        'agent_id', 'cash_advance'
    ];
}
