<?php

namespace App\Http\Controllers\api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\payment;
use App\savings;
use App\deductions;
use App\branch;

class PaymentController extends Controller
{
    public function create(Request $request) {
    	$v = validator($request->only('branch_id', 'agent_id', 'payment_period_id', 'work_days', 'ot_hours', 'rest_days', 'regular_holiday', 'special_holiday', 'ot_approval', 'dtr', 'paid_by'), [
	        'branch_id' => 'required',
	        'agent_id' => 'required',
	        'payment_period_id' => 'required',
	        'work_days' => 'required',
	        'ot_hours' => 'required',
	        'rest_days' => 'required',
	        'regular_holiday' => 'required',
	        'special_holiday' => 'required',
	        'dtr' => 'required',
	        'paid_by' => 'required'
	    ]);

	    if ($v->fails()) {
	        return response()->json($v->errors()->all(), 400);
	    }

	    $data = request()->only('branch_id', 'agent_id', 'payment_period_id', 'work_days', 'ot_hours', 'rest_days', 'regular_holiday', 'special_holiday', 'ot_approval', 'dtr', 'paid_by');

	    function handleFiles($fileImage, $passType) {
	      $exploded = explode(',', $fileImage);

	      $decoded = base64_decode($exploded[1]);

	      if(str_contains($exploded[0], 'jpeg'))
	        $extension = 'jpg';
	      else
	        $extension = 'png';

	      $fileName = str_random().'.'.$extension;

	      $type = $passType === 'ot' ? 'OT' : 'DTR';

	      $path = public_path().'/uploads/payment/'.$type.$fileName;

	      file_put_contents($path , $decoded);

	      return $fileName;
	    }

	    if($data['ot_approval'] !== null) {
	      $ot_file = handleFiles($data['ot_approval'], 'ot');
	    } else {
	      $ot_file = '';
	    }

	    if($data['dtr'] !== null) {
	      $dtr = handleFiles($data['dtr'], 'dtr');
	    } else {
	      $dtr = '';
	    }

	    $deduction = deductions::find(1);

	    if (!$deduction) {
            $sss = 0;
            $pagibig = 0;
            $phil_health = 0;
            $savings_deduction = 0;
        } else {
        	$sss = $deduction->sss;
            $pagibig = $deduction->pag_ibig;
            $phil_health = $deduction->phil_health;
            $savings_deduction = $deduction->savings;
        }

        $branch = branch::where('id', $data['branch_id'])->first();

        $totalOT = $branch->ot_rates * $data['ot_hours'];
        $totalRestDay = $branch->rest_days * $data['rest_days'];
        $totalRegularHoliday = $branch->regular_holidays * $data['regular_holiday'];
        $totalSpecialHoliday = $branch->special_holidays * $data['special_holiday'];
        $totalRate = $branch->rate * $data['work_days'];
        $totalPayment = $totalOT + $totalRestDay + $totalRegularHoliday + $totalSpecialHoliday + $totalRate;
        $totalPayment = $totalPayment + $branch->allowance;

        $savings = savings::where('agent_id', $data['agent_id'])->first();
        
        if($savings->total_savings < 3500) {
        	$testIfover = $savings->total_savings + $savings_deduction;
        	if($testIfover > 3500) {
        		$savings_deduction = 3500 - $savings->total_savings;
        	}
        	$totalPayment = $totalPayment - $savings_deduction;
        	$savings->total_savings = $savings->total_savings + $savings_deduction;
        	$savings->save();
        } else {
        	$savings_deduction = 0;
        }
        $caBalance = $savings->ca_balance - $savings->deduction_rate;
        if ($caBalance > 0) {
        	$deductedByCA = $savings->deduction_rate;
        	$savings->ca_balance = $caBalance;
        	$savings->save();
        } else {
        	$deductedByCA = $savings->ca_balance;
        	$caBalance = 0;
        	$savings->ca_balance = $caBalance;
        	$savings->save();
        }

        $totalPayment = $totalPayment - $sss;
        $totalPayment = $totalPayment - $pagibig;
        $totalPayment = $totalPayment - $phil_health;
        $totalPayment = $totalPayment - $deductedByCA;

        $isExisting = payment::where('agent_id', $data['agent_id'])->where('branch_id', $data['branch_id'])->where('payment_period_id', $data['payment_period_id'])->first();
        if (!$isExisting) {
	        $payment = payment::create([
		        'agent_id' => $data['agent_id'],
		        'branch_id' => $data['branch_id'],
		        'payment_period_id' => $data['payment_period_id'],
		        'work_days' => $data['work_days'],
		        'ot_hours' => $data['ot_hours'],
		        'rest_days' => $data['rest_days'],
		        'regular_holiday' => $data['regular_holiday'],
		        'special_holiday' => $data['special_holiday'],
		        'ot_approval' => 'OT' . $ot_file,
		        'dtr' => 'DTR'. $dtr,
		        'paid_by' => $data['paid_by'],
		        'rate' => $branch->rate,
		        'allowance' => $branch->allowance,
		        'ot_rates' => $branch->ot_rates,
		        'regular_holiday_rate' => $branch->regular_holidays,
		        'special_holiday_rate' =>$branch->special_holidays,
		        'rest_day_rate' => $branch->rest_days,
		        'sss' => $sss,
		        'pag_ibig' => $pagibig,
		        'phil_health' => $phil_health,
		        'savings' => $savings_deduction,
		        'ca_deduction' => $deductedByCA,
		        'total_paid' => $totalPayment
		    ]);

	        $response = ["status" => "success", "data" => $payment->toArray()];
			return response(json_encode($response), 200, ["Content-Type" => "application/json"]);
		} else {
			$response = ["status" => "error", "data" => 'Agent already paid'];
			return response(json_encode($response), 400, ["Content-Type" => "application/json"]);
		}
    }
}
