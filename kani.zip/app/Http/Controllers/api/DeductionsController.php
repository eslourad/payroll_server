<?php

namespace App\Http\Controllers\api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\deductions;

class DeductionsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $deduction = deductions::find(1);
        $response = ["status" => "success", "data" => $deduction->toArray()];
        return response(json_encode($response), 200, ["Content-Type" => "application/json"]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        $v = validator($request->only('sss', 'pag_ibig', 'phil_health', 'savings'), [
            'sss' => 'required|integer',
            'pag_ibig' => 'required|integer',
            'phil_health' => 'required|integer',
            'savings' => 'required|integer'
        ]);

        if ($v->fails()) {
            return response()->json($v->errors()->all(), 400);
        }

        $data = request()->only('sss', 'pag_ibig', 'phil_health', 'savings');

        $deduction = deductions::where('id', 1)->first();
        if (!$deduction) {
            $deduction = deductions::create([
                'sss' => $data['sss'],
                'pag_ibig' => $data['pag_ibig'],
                'phil_health' => $data['phil_health'],
                'savings' => $data['savings']
            ]);
            $response = ["status" => "success", "data" => 'Deduction created'];
            return response(json_encode($response), 200, ["Content-Type" => "application/json"]);
        } else {
            $deduction->sss = $data['sss'];
            $deduction->pag_ibig = $data['pag_ibig'];
            $deduction->phil_health = $data['phil_health'];
            $deduction->savings = $data['savings'];
            $deduction = $deduction->save();
            $response = ["status" => "success", "data" => 'Deduction information updated'];
            return response(json_encode($response), 200, ["Content-Type" => "application/json"]);
        }
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\deductions  $deductions
     * @return \Illuminate\Http\Response
     */
    public function show(deductions $deductions)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\deductions  $deductions
     * @return \Illuminate\Http\Response
     */
    public function edit(deductions $deductions)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\deductions  $deductions
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, deductions $deductions)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\deductions  $deductions
     * @return \Illuminate\Http\Response
     */
    public function destroy(deductions $deductions)
    {
        //
    }
}
