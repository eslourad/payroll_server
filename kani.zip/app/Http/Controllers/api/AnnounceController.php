<?php

namespace App\Http\Controllers\api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\announcements;

class AnnounceController extends Controller
{	
	public function index()
    {
        $announcements = announcements::all();

        $response = ["status" => "success", "data" => $announcements->toArray()];
        return response(json_encode($response), 200, ["Content-Type" => "application/json"]);
    }

    public function create(Request $request)
    {
	    $v = validator($request->only('title', 'body'), [
	        'title' => 'required',
	        'body' => 'required'
	    ]);

	    if ($v->fails()) {
	        return response()->json($v->errors()->all(), 400);
	    }

	    $data = request()->only('title', 'body');

    	$branch = announcements::create([
	        'title' => $data['title'],
	        'body' => $data['body']
	    ]);

	    $response = ["status" => "success", "data" => $branch->toArray()];
		return response(json_encode($response), 200, ["Content-Type" => "application/json"]);
   
	}

	public function delete(Request $request)
    {
	    $v = validator($request->only('id'), [
	        'id' => 'required'
	    ]);

	    if ($v->fails()) {
	        return response()->json($v->errors()->all(), 400);
	    }

	    $data = request()->only('id');

    	$announcement = announcements::where('id',$data['id'])->delete();

	    $response = ["status" => "success", "data" => 'Successfully deleted'];
		return response(json_encode($response), 200, ["Content-Type" => "application/json"]);
   
	}
}
