<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class savings extends Model
{
	protected $fillable = [
        'ca_balance', 'total_savings', 'deduction_rate', 'agent_id'
    ];
}
